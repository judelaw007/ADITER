#!/usr/bin/env python3
"""
Convert generated markdown notes to professional Word documents
"""

from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import re

OUTPUT_DIR = Path("generated_notes")
WORD_DIR = Path("generated_notes/word")

# Color scheme
NAVY_BLUE = RGBColor(31, 78, 120)      # #1F4E78
DARK_GREY = RGBColor(68, 84, 106)      # #44546A
MEDIUM_GREY = RGBColor(127, 127, 127)  # #7F7F7F
LIGHT_GREY = RGBColor(242, 242, 242)   # #F2F2F2

class MarkdownToWord:
    def __init__(self):
        WORD_DIR.mkdir(exist_ok=True)
    
    def setup_styles(self, doc):
        """Setup document styles"""
        styles = doc.styles
        
        # Heading 1
        h1 = styles['Heading 1']
        h1.font.size = Pt(18)
        h1.font.bold = True
        h1.font.color.rgb = NAVY_BLUE
        
        # Heading 2
        h2 = styles['Heading 2']
        h2.font.size = Pt(14)
        h2.font.bold = True
        h2.font.color.rgb = DARK_GREY
        
        # Heading 3
        h3 = styles['Heading 3']
        h3.font.size = Pt(12)
        h3.font.bold = True
        h3.font.color.rgb = MEDIUM_GREY
        
        # Normal
        normal = styles['Normal']
        normal.font.name = 'Calibri'
        normal.font.size = Pt(11)
        normal.paragraph_format.line_spacing = 1.15
    
    def parse_markdown_line(self, line):
        """Parse markdown formatting"""
        # Bold: **text** or __text__
        line = re.sub(r'\*\*(.+?)\*\*', r'<bold>\1</bold>', line)
        line = re.sub(r'__(.+?)__', r'<bold>\1</bold>', line)
        
        # Italic: *text* or _text_
        line = re.sub(r'\*(.+?)\*', r'<italic>\1</italic>', line)
        line = re.sub(r'_(.+?)_', r'<italic>\1</italic>', line)
        
        return line
    
    def add_formatted_paragraph(self, doc, text, style='Normal'):
        """Add paragraph with inline formatting"""
        para = doc.add_paragraph(style=style)
        
        # Split by formatting tags
        parts = re.split(r'(<bold>|</bold>|<italic>|</italic>)', text)
        
        bold = False
        italic = False
        
        for part in parts:
            if part == '<bold>':
                bold = True
            elif part == '</bold>':
                bold = False
            elif part == '<italic>':
                italic = True
            elif part == '</italic>':
                italic = False
            elif part:
                run = para.add_run(part)
                run.bold = bold
                run.italic = italic
    
    def convert_file(self, md_file):
        """Convert a markdown file to Word document"""
        
        print(f"Converting: {md_file.name}")
        
        # Read markdown
        with open(md_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Create document
        doc = Document()
        self.setup_styles(doc)
        
        # Setup page
        section = doc.sections[0]
        section.page_height = Inches(11.69)  # A4
        section.page_width = Inches(8.27)
        section.left_margin = Inches(0.98)   # 2.5cm
        section.right_margin = Inches(0.98)
        section.top_margin = Inches(0.98)
        section.bottom_margin = Inches(0.98)
        
        # Add header
        header = section.header
        header_para = header.paragraphs[0]
        header_para.text = "ADIT Module 3.04 - Energy Resources"
        header_para.alignment = WD_ALIGN_PARAGRAPH.LEFT
        header_para.style.font.size = Pt(9)
        header_para.style.font.color.rgb = MEDIUM_GREY
        
        # Add footer with page numbers
        footer = section.footer
        footer_para = footer.paragraphs[0]
        footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Process content line by line
        lines = content.split('\n')
        in_code_block = False
        in_example = False
        
        for line in lines:
            line = line.rstrip()
            
            # Skip empty lines in some contexts
            if not line:
                if not in_code_block:
                    doc.add_paragraph()
                continue
            
            # Code blocks
            if line.startswith('```'):
                in_code_block = not in_code_block
                continue
            
            if in_code_block:
                para = doc.add_paragraph(line, style='Normal')
                para.style.font.name = 'Courier New'
                para.style.font.size = Pt(10)
                continue
            
            # Headings
            if line.startswith('# '):
                doc.add_heading(line[2:], level=1)
            elif line.startswith('## '):
                doc.add_heading(line[3:], level=2)
            elif line.startswith('### '):
                doc.add_heading(line[4:], level=3)
            
            # Worked examples (special formatting)
            elif 'WORKED EXAMPLE' in line or line.startswith('═══'):
                if '═══' in line:
                    para = doc.add_paragraph('_' * 60)
                    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                else:
                    para = doc.add_paragraph(line, style='Heading 3')
                    para.style.font.color.rgb = NAVY_BLUE
            
            # Bullet points
            elif line.startswith('- ') or line.startswith('* '):
                parsed = self.parse_markdown_line(line[2:])
                self.add_formatted_paragraph(doc, parsed, style='List Bullet')
            
            # Numbered lists
            elif re.match(r'^\d+\.\s', line):
                text = re.sub(r'^\d+\.\s', '', line)
                parsed = self.parse_markdown_line(text)
                self.add_formatted_paragraph(doc, parsed, style='List Number')
            
            # Regular paragraph
            else:
                parsed = self.parse_markdown_line(line)
                self.add_formatted_paragraph(doc, parsed)
        
        # Save document
        output_file = WORD_DIR / f"{md_file.stem}.docx"
        doc.save(output_file)
        
        print(f"  ✓ Saved: {output_file.name}")
        return output_file
    
    def convert_all(self):
        """Convert all markdown files"""
        md_files = list(OUTPUT_DIR.glob("*.md"))
        
        if not md_files:
            print("No markdown files found to convert!")
            return
        
        print(f"Found {len(md_files)} markdown files to convert\n")
        
        for md_file in md_files:
            try:
                self.convert_file(md_file)
            except Exception as e:
                print(f"  ✗ Error: {str(e)}")
        
        print(f"\n✓ Conversion complete! Word files in: {WORD_DIR}")

def main():
    converter = MarkdownToWord()
    converter.convert_all()

if __name__ == "__main__":
    main()
