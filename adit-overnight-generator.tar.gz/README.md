# ADIT Energy Resources - Automated Note Generator

Generate all 72 ADIT study notes automatically while you sleep! 🌙

## 🎯 What This Does

This system automatically generates professional ADIT Energy Resources study notes:
- ✅ **72 topics** from your syllabus
- ✅ **Full research** using web search for current information
- ✅ **Professional formatting** with tables, examples, and visuals
- ✅ **Resumable** - picks up where it left off if interrupted
- ✅ **Progress tracking** - always know what's completed
- ✅ **Word documents** ready for immediate use

## 📋 What You Need

1. **Python 3.8+** (check: `python3 --version`)
2. **Anthropic API key** from https://console.anthropic.com
3. **Your ADIT syllabus CSV** (already included)
4. **5-10 hours** of uninterrupted time (let it run overnight)

## 🚀 Quick Start (5 Minutes Setup)

### Step 1: Get Your API Key

1. Go to https://console.anthropic.com
2. Sign up/log in
3. Navigate to API Keys
4. Create a new key
5. Copy it (starts with `sk-ant-...`)

### Step 2: Configure the Generator

Edit `generate_adit_notes.py` and replace:
```python
API_KEY = "YOUR_ANTHROPIC_API_KEY_HERE"
```
With your actual key:
```python
API_KEY = "sk-ant-your-actual-key-here"
```

### Step 3: Make Scripts Executable

```bash
chmod +x start_overnight.sh
chmod +x generate_adit_notes.py
chmod +x convert_to_word.py
```

### Step 4: Start Overnight Generation

```bash
./start_overnight.sh
```

That's it! Go to sleep. 😴

## 📊 What Happens Overnight

### Generation Process (Per Topic)

1. **Research Phase** (5-10 min)
   - Searches for current legislation
   - Finds recent case law
   - Checks OECD/UN/World Bank guidelines
   - Identifies 2025 developments

2. **Content Creation** (10-15 min)
   - Generates comprehensive note
   - Creates worked examples
   - Builds tables and diagrams
   - Formats professionally

3. **Quality Check** (2-5 min)
   - Verifies completeness
   - Checks statutory references
   - Validates calculations
   - Saves markdown file

**Total per topic**: ~25 minutes
**10 topics overnight**: ~4-5 hours

## 📁 Output Structure

```
generated_notes/
├── Tax_and_fiscal_regimes_Licence_and_concession_regimes.md
├── Tax_and_fiscal_regimes_Production_sharing_contracts.md
├── Transfer_pricing_Transfer_pricing_methods.md
├── ...
└── word/  (after conversion)
    ├── Tax_and_fiscal_regimes_Licence_and_concession_regimes.docx
    ├── Tax_and_fiscal_regimes_Production_sharing_contracts.docx
    └── ...
```

## 🔄 Managing Generation

### Check Progress

```bash
# View real-time log
tail -f generation_log.txt

# View overnight log
tail -f overnight_generation.log

# Check progress file
cat generation_progress.json
```

### Resume After Stop

The system automatically resumes from where it left off:

```bash
./start_overnight.sh
```

Or manually:
```bash
python3 generate_adit_notes.py --continue
```

### Generate Specific Number

```bash
# Generate next 5 topics
python3 generate_adit_notes.py 5

# Generate next 20 topics
python3 generate_adit_notes.py 20

# Generate ALL remaining topics (could take 20+ hours!)
python3 generate_adit_notes.py --all
```

## 📝 Convert to Word Documents

After generation completes:

```bash
python3 convert_to_word.py
```

This creates professionally formatted Word documents in `generated_notes/word/`

## 💰 Cost Estimation

**Per topic**: ~$0.50-$1.50 (depending on complexity)
**10 topics**: ~$10-15
**All 72 topics**: ~$60-100

Tips to reduce costs:
- Generate in batches of 10
- Review quality before generating all
- Use during off-peak hours

## 🔍 Progress Tracking

The system maintains `generation_progress.json`:

```json
{
  "completed": [
    "Tax and fiscal regimes - Licence and concession regimes",
    "Tax and fiscal regimes - Production sharing contracts"
  ],
  "failed": [],
  "last_index": 1,
  "started_at": "2025-11-14T22:00:00"
}
```

- **completed**: Successfully generated notes
- **failed**: Topics that encountered errors
- **last_index**: Last processed topic (for resuming)
- **started_at**: When generation began

## 🛠️ Troubleshooting

### "API key not configured"
Edit `generate_adit_notes.py` and add your Anthropic API key

### "Rate limit exceeded"
The script includes automatic delays. If you still hit limits, increase sleep time:
```python
time.sleep(5)  # Change 3 to 5 or more
```

### "Connection error"
Check your internet connection. The script will log the error and continue with the next topic.

### Generated note is incomplete
Check `generation_log.txt` for errors. The note will be marked as failed and you can regenerate it.

### Want to regenerate a specific topic
Delete the markdown file and it will be regenerated on next run.

## 📈 Recommended Workflow

### Night 1 (Tonight!)
```bash
./start_overnight.sh  # Generates 10 topics
```

### Morning Review
1. Check `generation_log.txt` for any errors
2. Open a few Word docs to verify quality
3. Note any adjustments needed

### Night 2-7
Repeat overnight generation until all 72 complete.

### Final Quality Pass
1. Convert all to Word: `python3 convert_to_word.py`
2. Review key topics
3. Add any custom content needed
4. You're exam ready! 🎓

## 🎓 Customization

### Adjust Word Count Per Level

Edit in `generate_adit_notes.py`:
```python
WORD_COUNTS = {
    "Broad": 3000,      # Increase for more detail
    "Detailed": 4500,
    "Advanced": 6000
}
```

### Change Number of Examples

The system uses the CSV specification, but you can override:
```python
num_examples = int(topic['examples']) + 1  # Add 1 extra example
```

### Modify Research Queries

Edit the `create_generation_prompt` function to add specific searches.

## 📚 What Each Note Contains

✓ Core statutory framework with specific references
✓ Technical rules (rates, thresholds, conditions)
✓ Analytical depth (interactions, cross-border issues)
✓ Application methodology (step-by-step guides)
✓ Required number of worked examples
✓ Visual elements (20% of content)
✓ 2025 developments (integrated naturally)
✓ Professional formatting ready for Word

## ⚠️ Important Notes

1. **Don't interrupt mid-topic** - Let each topic complete
2. **Check API costs** - Monitor your Anthropic console
3. **Review quality** - Always check generated content
4. **Keep CSV updated** - Reflects your current syllabus
5. **Backup regularly** - Git commit generated notes

## 🎯 Success Metrics

After overnight generation, you should see:
- ✅ 10 markdown files in `generated_notes/`
- ✅ Progress file updated
- ✅ Log file with timestamps
- ✅ No errors in log
- ✅ Word conversion successful

## 📞 Support

If you encounter issues:
1. Check `generation_log.txt` for specific errors
2. Verify API key is correct
3. Ensure internet connection is stable
4. Check Anthropic API status
5. Review progress file for state

## 🚀 Ready to Start?

1. ✅ API key configured
2. ✅ Scripts executable
3. ✅ Requirements installed

Run:
```bash
./start_overnight.sh
```

Then go to sleep! 🌙

Your ADIT notes will be waiting in the morning. ☕
