#!/bin/bash

# ADIT Overnight Generation Starter
# Run this before bed!

echo "╔══════════════════════════════════════════════════════════╗"
echo "║    ADIT Energy Resources - Overnight Note Generator      ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Setting up Python environment..."
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
else
    source venv/bin/activate
fi

echo "🚀 Starting overnight generation..."
echo ""
echo "Configuration:"
echo "  • Generating: 10 topics per session"
echo "  • Each topic: ~25 minutes"
echo "  • Estimated time: 4-5 hours"
echo "  • Progress saved automatically"
echo ""

# Check if API key is set
if grep -q "YOUR_ANTHROPIC_API_KEY_HERE" generate_adit_notes.py; then
    echo "⚠️  WARNING: API key not configured!"
    echo ""
    echo "Please edit generate_adit_notes.py and add your Anthropic API key:"
    echo "  API_KEY = \"sk-ant-your-key-here\""
    echo ""
    read -p "Press Enter after updating the API key..."
fi

# Start generation
echo "🌙 Starting overnight generation..."
echo "   You can safely close this terminal and go to sleep!"
echo ""

# Run in background with logging
nohup python3 generate_adit_notes.py 10 > overnight_generation.log 2>&1 &

PID=$!
echo "✓ Generation started! (PID: $PID)"
echo ""
echo "📊 Monitor progress:"
echo "   • Check: generation_log.txt"
echo "   • View output: overnight_generation.log"
echo "   • Notes saved in: generated_notes/"
echo ""
echo "🛏️  Goodnight! Your notes will be ready in the morning."
echo ""
echo "To check status: tail -f generation_log.txt"
echo "To stop: kill $PID"
