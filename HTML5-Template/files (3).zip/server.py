#!/usr/bin/env python3
"""
Simple HTTP Server for MojiTax Templates
Run this script to serve the templates locally
"""

import http.server
import socketserver
import os
import sys
import webbrowser
from pathlib import Path

PORT = 8000
HOST = "localhost"

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Prevent caching for better development experience
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        return super().end_headers()

def main():
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    # Create the server
    with socketserver.TCPServer(("", PORT), MyHTTPRequestHandler) as httpd:
        url = f"http://{HOST}:{PORT}"
        print(f"")
        print(f"🚀 MojiTax Templates Server Started!")
        print(f"━" * 50)
        print(f"📍 Server running at: {url}")
        print(f"🌐 Open your browser to: {url}")
        print(f"")
        print(f"📁 Current directory: {script_dir}")
        print(f"🛑 Press Ctrl+C to stop the server")
        print(f"━" * 50)
        print(f"")
        
        # Try to open browser automatically
        try:
            webbrowser.open(url)
            print(f"✓ Browser opened automatically!")
            print(f"")
        except:
            print(f"⚠ Couldn't open browser automatically.")
            print(f"  Please open {url} manually in your browser.")
            print(f"")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print(f"")
            print(f"🛑 Server stopped.")
            print(f"")
            sys.exit(0)

if __name__ == "__main__":
    main()
