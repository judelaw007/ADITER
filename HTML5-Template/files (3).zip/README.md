# MojiTax HTML5 Presentation Templates

Professional, responsive HTML5 templates for tax education and professional development platforms.

## 📋 Overview

This template system provides 6 fully customizable HTML5 pages designed for premium tax education content delivery. Each template features sophisticated styling, responsive design, and professional branding suitable for tax professionals and financial experts.

### Template Suite

1. **01-welcome.html** - Welcome landing page
   - Welcoming hero section with logo
   - Call-to-action button
   - Perfect for course homepage or module opener

2. **02-curriculum.html** - Course curriculum overview
   - Module cards with descriptions
   - Interactive grid layout
   - Lesson counts and time estimates

3. **03-topic.html** - Topic introduction
   - Sidebar layout with learning objectives
   - Key concepts overview
   - Learning timeline and CTA buttons

4. **04-content.html** - Main educational content
   - Structured content delivery
   - Bullet points and examples
   - Tables and highlight boxes
   - Progress indicators

5. **05-assessment.html** - Interactive knowledge assessment
   - Multiple-choice questions
   - Progress tracking
   - Question counter and scoring info
   - Professional styling for assessments

6. **06-completion.html** - Course completion celebration
   - Achievement statistics
   - Certificate information
   - Next steps guidance
   - Motivational messaging

## 🎨 Design Features

### Professional Styling
- **Color Palette**: Modern blue and orange gradient system
  - Primary: #003F87 (Deep Navy)
  - Secondary: #0066CC (Professional Blue)
  - Accent: #FF6B35 (Energetic Orange)
  - Success: #27AE60 (Achievement Green)

- **Visual Elements**:
  - Gradient backgrounds and buttons
  - Subtle shadow effects
  - Glass-morphism accents
  - Smooth transitions and hover effects
  - Professional typography with letter spacing

- **Responsive Design**: 
  - Mobile-first approach
  - Adapts perfectly to desktop, tablet, and mobile
  - Flexible grid layouts
  - Touch-friendly interface elements

### Accessibility Features
- Semantic HTML5 structure
- WCAG-compliant color contrasts
- Keyboard navigation support
- Focus indicators on interactive elements
- Screen reader friendly markup

## 🚀 Getting Started

### Quick Start (3 Steps)

1. **Download** all 7 files (index.html + 6 template files)
2. **Run a local web server** (see instructions below)
3. **Navigate** to http://localhost:8000 and click through templates

### Setting Up a Web Server

Choose one of these options:

#### Option 1: Python (Easiest - Most Common)
```bash
# Python 3
python3 -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```
Then visit: `http://localhost:8000`

#### Option 2: Node.js
```bash
# Create a simple server
node -e "require('http').createServer((req,res)=>{require('fs').readFile(req.url.slice(1)|'index.html',(e,d)=>res.end(d))}).listen(8000)"
```
Then visit: `http://localhost:8000`

#### Option 3: Live Server (VS Code)
Install the "Live Server" extension and right-click any HTML file → "Open with Live Server"

#### Option 4: Built-in Server Script
Create `server.py` or `server.js` in your project folder and run it

## 📝 Customization Guide

### Changing Colors

Edit the CSS variables in the `<style>` section of each template:

```css
:root {
    --primary: #003F87;      /* Main brand color */
    --secondary: #0066CC;    /* Secondary color */
    --accent: #FF6B35;       /* Highlight color */
    --light-bg: #F8F9FA;     /* Background */
    --dark-text: #1A1F36;    /* Text color */
}
```

### Customizing Content

Each template has clearly labeled content sections:

**Welcome Page:**
- Logo (emoji)
- Title and tagline
- Description text
- Button text and links

**Curriculum Page:**
- Module titles and descriptions
- Duration and lesson counts
- Module links

**Content Page:**
- Section titles
- Paragraphs and bullet points
- Tables and examples
- Box callouts

### Changing Fonts

Replace the font stack in the `body` style:

```css
body {
    font-family: 'Your Font', sans-serif;
}
```

Common professional font combinations:
- `'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif`
- `'Inter', 'Open Sans', sans-serif`
- `Georgia, 'Times New Roman', serif` (traditional)

## 🔗 Linking Templates Together

All templates are pre-linked in a logical flow:

```
index.html (Navigation Hub)
    ↓
01-welcome.html → 02-curriculum.html
    ↓
03-topic.html → 04-content.html
    ↓
05-assessment.html → 06-completion.html
```

To customize links, find and update the `href` attributes in anchor tags.

## 📱 Responsive Breakpoints

Templates include media queries for:
- **Desktop**: Full layout (1200px+)
- **Tablet**: Adjusted grid and spacing (768px - 1199px)
- **Mobile**: Single column layout (<768px)

Customize breakpoints by modifying:
```css
@media (max-width: 768px) {
    /* Mobile styles */
}
```

## 🎯 Best Practices

### Content Best Practices
- Keep titles under 65 characters
- Use 3-6 bullet points per section
- Break content into scannable chunks
- Include examples and real scenarios
- Progressive disclosure of information

### Design Best Practices
- Maintain consistent spacing (use CSS variables)
- Limit text width to 60-75 characters for readability
- Use whitespace strategically
- Keep interactive elements clearly labeled
- Test on actual devices, not just browsers

### Performance Best Practices
- Templates are self-contained (no external dependencies)
- CSS is inline for fast loading
- Minimal JavaScript
- Optimized for mobile-first approach
- Typically load in under 1 second

## 🔧 Advanced Customization

### Adding Custom Fonts

Link to Google Fonts in the `<head>`:

```html
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
```

Then update CSS:
```css
body {
    font-family: 'Poppins', sans-serif;
}
```

### Animation Enhancements

Templates include basic transitions. Add more with CSS:

```css
.element {
    animation: slideIn 0.5s ease-out;
}

@keyframes slideIn {
    from { transform: translateX(-100%); }
    to { transform: translateX(0); }
}
```

### Adding JavaScript Interactivity

Templates are designed to work without JavaScript, but you can add:
- Form validation
- Dynamic content loading
- Quiz scoring
- Progress tracking
- Analytics integration

## 📊 Browser Support

- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions
- Mobile browsers: iOS Safari 12+, Chrome Android

Templates use standard CSS3 Grid and Flexbox with graceful degradation.

## 🎓 Use Cases

Ideal for:
- Tax education platforms
- Professional development courses
- Corporate training systems
- CPA continuing education
- Financial advisor training
- Compliance certification programs
- Online learning modules
- Employee onboarding

## 📦 Files Included

```
MojiTax-Templates/
├── index.html                 # Navigation hub (start here)
├── 01-welcome.html           # Course welcome page
├── 02-curriculum.html        # Module overview
├── 03-topic.html             # Topic introduction
├── 04-content.html           # Educational content
├── 05-assessment.html        # Knowledge assessment
├── 06-completion.html        # Completion celebration
└── README.md                 # This file
```

## ⚡ Quick Tips

1. **Test Locally**: Always test in a browser before deployment
2. **Mobile First**: Design and test mobile view first
3. **Accessibility**: Check color contrast and keyboard navigation
4. **Performance**: Keep CSS and HTML minimal
5. **Branding**: Establish color palette early
6. **Consistency**: Use same spacing and typography throughout
7. **Links**: Update all href attributes for your domain
8. **Images**: Optimize file sizes for web

## 🆘 Troubleshooting

**Q: Links don't work when opening HTML files directly**
A: You need a web server. Use Python/Node server (see Getting Started)

**Q: Styles look broken**
A: Clear browser cache (Ctrl+Shift+Delete or Cmd+Shift+Delete)

**Q: Mobile view looks wrong**
A: Check viewport meta tag is present: `<meta name="viewport" content="width=device-width, initial-scale=1.0">`

**Q: Colors don't match my brand**
A: Update the CSS color variables at the top of each template

## 📞 Support & Documentation

For more information on customization:
- Review the inline CSS comments in each template
- Check HTML structure for content sections
- Test changes in browser developer tools first
- Validate HTML with W3C HTML Validator

## 📄 License

These templates are provided for educational and professional use. Customize freely for your organization's needs.

## 💡 Next Steps

1. Choose your starting template
2. Update the color palette to match your brand
3. Customize content with your course materials
4. Test on mobile devices
5. Deploy to your web server
6. Gather student feedback and iterate

---

**Happy Learning! 🎓**

Built with care for professional tax education and financial services training.
