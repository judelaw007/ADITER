# MojiTax Templates - Quick Start Guide

## 🎯 Get Started in 5 Minutes

### Step 1: Download Files
All files are ready to download from the outputs folder:
- `index.html` (main navigation)
- `01-welcome.html` through `06-completion.html` (6 template pages)
- `README.md` (full documentation)
- `server.py` (optional - for local testing)

### Step 2: Choose Your Setup Method

#### ✨ Easiest: Use Our Python Server
```bash
# Navigate to your template folder
cd /path/to/mojitax-templates

# Run the server
python3 server.py

# Browser should open automatically to http://localhost:8000
```

#### 🐍 Python (No Extra Files Needed)
```bash
# Navigate to your template folder
cd /path/to/mojitax-templates

# Start built-in server
python3 -m http.server 8000

# Visit http://localhost:8000 in your browser
```

#### 📝 VS Code Live Server
1. Install "Live Server" extension
2. Right-click on `index.html`
3. Select "Open with Live Server"
4. Browser opens automatically

#### 🌐 Online
Upload files to your web server and access via your domain.

### Step 3: View the Templates
Open your browser and navigate to `http://localhost:8000`

Click "View Template" on any template card to see the live page.

### Step 4: Customize

#### Change Colors
Edit the CSS variables in each template (around line 15):
```css
:root {
    --primary: #003F87;      /* Your brand blue */
    --secondary: #0066CC;    /* Your brand accent */
    --accent: #FF6B35;       /* Your brand highlight */
}
```

#### Update Content
Find and edit the text content directly in the HTML:
- Headings (`<h1>`, `<h2>`, etc.)
- Paragraphs (`<p>`)
- List items (`<li>`)
- Button text and links (`<a>`)

#### Quick Content Replacements
Search and replace these common items:
- "MojiTax" → Your course/company name
- "Tax" → Your course topic
- "🦅" → Your logo/emoji
- "Fundamentals" → Your module name

### Step 5: Test & Deploy

#### Testing
- Test in browser (Chrome, Firefox, Safari)
- Check mobile view (use browser DevTools)
- Test all links and buttons
- Verify forms (Assessment template)

#### Deployment
1. Upload all files to your web server
2. Update all links to match your domain
3. Test live version
4. Monitor for feedback

## 📋 Template Purposes

| Template | Purpose | When to Use |
|----------|---------|------------|
| Welcome | Course entry point | Course homepage |
| Curriculum | Show all modules | Module selection page |
| Topic | Introduce lesson | Start of each lesson |
| Content | Teach material | Main lesson content |
| Assessment | Test knowledge | After lesson |
| Completion | Celebrate success | Course/module end |

## 🎨 Color Customization Examples

### Modern Blue Professional
```css
--primary: #003F87;      /* Deep blue */
--secondary: #0066CC;    /* Bright blue */
--accent: #FF6B35;       /* Orange accent */
```

### Corporate Green
```css
--primary: #1B5E3F;      /* Forest green */
--secondary: #2E8B57;    /* Sea green */
--accent: #DAA520;       /* Gold */
```

### Minimalist Monochrome
```css
--primary: #1A1A1A;      /* Dark gray */
--secondary: #4A4A4A;    /* Medium gray */
--accent: #FF6B6B;       /* Red */
```

### Warm Professional
```css
--primary: #8B4513;      /* Saddle brown */
--secondary: #CD853F;    /* Peru */
--accent: #FFD700;       /* Gold */
```

## 🔗 Linking Navigation

Templates are pre-linked in sequence:
```
01-welcome → 02-curriculum → 03-topic → 04-content → 05-assessment → 06-completion
```

Update links by changing `href` values in `<a>` tags.

Example:
```html
<!-- Default -->
<a href="02-curriculum.html" class="btn btn-primary">Start Course</a>

<!-- Custom path -->
<a href="/learning/module-2.html" class="btn btn-primary">Start Course</a>
```

## ✅ Customization Checklist

- [ ] Downloaded all 7 files
- [ ] Set up local server
- [ ] Viewed all 6 templates
- [ ] Updated color palette
- [ ] Customized course titles
- [ ] Updated course content
- [ ] Tested on mobile
- [ ] Tested all links
- [ ] Customized module names
- [ ] Updated company/brand name
- [ ] Checked button text
- [ ] Verified learning objectives
- [ ] Updated assessment questions
- [ ] Customized completion message

## 🚀 Advanced Tips

### Using Custom Fonts
Add to `<head>` section:
```html
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@400;600&display=swap" rel="stylesheet">
```

Then update CSS:
```css
h1 { font-family: 'Playfair Display', serif; }
body { font-family: 'Lato', sans-serif; }
```

### Adding Your Logo
Replace emoji with image:
```html
<!-- Instead of -->
<div class="logo-circle">🦅</div>

<!-- Use -->
<div class="logo-circle">
    <img src="your-logo.png" alt="Logo" style="width: 80%; height: auto;">
</div>
```

### Embedding Videos
In content sections:
```html
<iframe width="100%" height="400" 
    src="https://www.youtube.com/embed/VIDEO_ID" 
    frameborder="0" allowfullscreen>
</iframe>
```

## 📱 Mobile Optimization

All templates are mobile-first. Key breakpoints:
- **Mobile**: < 768px (single column)
- **Tablet**: 768px - 1199px (adjusted layout)
- **Desktop**: 1200px+ (full layout)

Test by:
1. Opening DevTools (F12)
2. Click device toggle (mobile icon)
3. Try different device sizes

## 🐛 Troubleshooting

**"Cannot find module" error**
→ Make sure you're in the correct directory

**Styles not loading**
→ Clear browser cache (Ctrl+Shift+Delete)

**Links not working**
→ Check file names match exactly (case-sensitive)

**Mobile view broken**
→ Check viewport meta tag in `<head>`

**Colors look wrong**
→ Verify hex codes are correct (# symbol included)

## 📞 Need Help?

1. Check the full README.md documentation
2. Review HTML comments in templates
3. Validate HTML: https://validator.w3.org/
4. Check CSS: https://jigsaw.w3.org/css-validator/
5. Test colors: https://coolors.co/

## 🎉 You're All Set!

Your MojiTax templates are ready to customize and deploy. Start with one template, get comfortable with the customization process, then apply the same changes to all others.

**Happy building! 🚀**

---

For detailed documentation, see **README.md**
