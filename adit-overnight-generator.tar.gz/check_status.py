#!/usr/bin/env python3
"""
Check status of ADIT note generation
"""

import json
from pathlib import Path
from datetime import datetime

PROGRESS_FILE = "generation_progress.json"
LOG_FILE = "generation_log.txt"
OUTPUT_DIR = Path("generated_notes")

def load_progress():
    """Load progress file"""
    if Path(PROGRESS_FILE).exists():
        with open(PROGRESS_FILE, 'r') as f:
            return json.load(f)
    return None

def count_files():
    """Count generated files"""
    if not OUTPUT_DIR.exists():
        return 0
    return len(list(OUTPUT_DIR.glob("*.md")))

def get_last_log_lines(n=10):
    """Get last N lines from log"""
    if not Path(LOG_FILE).exists():
        return []
    
    with open(LOG_FILE, 'r') as f:
        lines = f.readlines()
    
    return lines[-n:]

def print_status():
    """Print generation status"""
    
    print("=" * 70)
    print("ADIT NOTE GENERATION - STATUS REPORT")
    print("=" * 70)
    print()
    
    # Load progress
    progress = load_progress()
    
    if not progress:
        print("❌ No generation has been started yet.")
        print()
        print("To start: ./start_overnight.sh")
        return
    
    # Basic stats
    completed = len(progress.get('completed', []))
    failed = len(progress.get('failed', []))
    total = 72  # Total topics in CSV
    remaining = total - completed - failed
    
    print(f"📊 PROGRESS OVERVIEW")
    print(f"   Total Topics: {total}")
    print(f"   ✓ Completed:  {completed} ({completed/total*100:.1f}%)")
    print(f"   ✗ Failed:     {failed}")
    print(f"   ⏳ Remaining:  {remaining}")
    print()
    
    # Files generated
    file_count = count_files()
    print(f"📁 FILES GENERATED")
    print(f"   Markdown files: {file_count}")
    print(f"   Location: {OUTPUT_DIR}/")
    print()
    
    # Start time
    if progress.get('started_at'):
        start = datetime.fromisoformat(progress['started_at'])
        print(f"🕐 TIMELINE")
        print(f"   Started: {start.strftime('%Y-%m-%d %H:%M:%S')}")
        
        elapsed = datetime.now() - start
        hours = elapsed.total_seconds() / 3600
        print(f"   Elapsed: {hours:.1f} hours")
        print()
    
    # Recent activity
    print(f"📝 RECENT ACTIVITY (Last 10 log entries)")
    print("-" * 70)
    log_lines = get_last_log_lines(10)
    for line in log_lines:
        print(f"   {line.rstrip()}")
    print()
    
    # Failed topics
    if failed > 0:
        print(f"⚠️  FAILED TOPICS")
        print("-" * 70)
        for fail in progress.get('failed', []):
            print(f"   • {fail['topic']}")
            print(f"     Error: {fail['error']}")
        print()
        print("   To retry: Delete progress file and run generation again")
        print()
    
    # Next steps
    print(f"🎯 NEXT STEPS")
    if remaining > 0:
        print(f"   • {remaining} topics remaining")
        print(f"   • Estimated time: {remaining * 0.5:.1f} hours")
        print(f"   • To continue: ./start_overnight.sh")
    else:
        print(f"   • ✓ All topics complete!")
        print(f"   • Convert to Word: python3 convert_to_word.py")
        print(f"   • Review notes in: {OUTPUT_DIR}/")
    
    print()
    print("=" * 70)

if __name__ == "__main__":
    print_status()
